package com.example.calc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private  int mCounter=1;
    Button buttonsub, buttonadd,btnok;
    TextView layers, respond;
    double a,b=2;
    double number1;
    String number2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnok=(Button)findViewById(R.id.btnok);
        buttonadd=(Button) findViewById(R.id.buttonadd);
        buttonsub=(Button) findViewById(R.id.buttonsub);
        layers=(TextView) findViewById(R.id.layers);
        respond=(TextView)findViewById(R.id.respond);
        Spinner spinner=findViewById(R.id.spinner1);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.opcje, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        buttonadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCounter++;
                layers.setText(Integer.toString(mCounter));
            }
        });

        buttonsub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCounter--;
                layers.setText(Integer.toString(mCounter));
            }
        });
        btnok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number1=a*b*mCounter;
                number1=Math.round(number1*100.0)/100;
                number2=String.valueOf(number1);
                respond.setText(number2);

            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(),text,Toast.LENGTH_SHORT).show();
        switch (position){
            case 0:
                a=1;
                break;
            case 1:
                a=1.2;
                break;
            case 2:
                a=1.4;
                break;
        }
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {}
}
